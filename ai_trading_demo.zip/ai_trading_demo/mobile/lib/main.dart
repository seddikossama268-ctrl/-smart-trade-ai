import 'package:flutter/material.dart';
import 'core/api_client.dart';

void main() => runApp(const TradingApp());

class TradingApp extends StatelessWidget {
  const TradingApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(useMaterial3: true, brightness: Brightness.dark),
      home: const Dashboard(),
    );
  }
}

class Dashboard extends StatefulWidget {
  const Dashboard({super.key});
  @override State<Dashboard> createState() => _DashboardState();
}

class _DashboardState extends State<Dashboard> {
  final api = ApiClient();
  final symbol = TextEditingController(text: 'BTCUSDT');
  Map<String,dynamic>? analysis;
  Map<String,dynamic>? account;
  bool loading = false;

  Future<void> analyze() async {
    setState(() => loading = true);
    try {
      final a = await api.analyze(symbol.text.trim().toUpperCase());
      final p = await api.account();
      setState(() { analysis = a; account = p; });
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: $e')));
    } finally { if (mounted) setState(() => loading = false); }
  }

  @override
  Widget build(BuildContext context) {
    final a = analysis;
    final p = account;
    return Scaffold(
      appBar: AppBar(title: const Text('AI Trading • PAPER')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        TextField(controller: symbol, textCapitalization: TextCapitalization.characters,
          decoration: const InputDecoration(labelText: 'Symbol', hintText: 'BTCUSDT')),
        const SizedBox(height: 12),
        FilledButton(onPressed: loading ? null : analyze,
          child: Text(loading ? 'Analyzing…' : 'Analyze Market')),
        const SizedBox(height: 16),
        if (p != null) Card(child: ListTile(
          title: Text('Virtual Balance: \$${(p['balance'] as num).toStringAsFixed(2)}'),
          subtitle: Text('Daily loss: ${((p['daily_loss'] as num)*100).toStringAsFixed(2)}%'),
        )),
        if (a != null) Card(child: Padding(padding: const EdgeInsets.all(16), child:
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('${a['signal']} • ${a['trend']}', style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
            Text('Price: ${a['price']}'),
            Text('Model confidence: ${((a['confidence'] as num)*100).toStringAsFixed(0)}%'),
            Text('RSI: ${(a['rsi'] as num).toStringAsFixed(2)}'),
            Text('MACD: ${(a['macd'] as num).toStringAsFixed(4)}'),
            Text('SMA20: ${(a['sma20'] as num).toStringAsFixed(2)}'),
            Text('SMA50: ${(a['sma50'] as num).toStringAsFixed(2)}'),
            if (a['stop_loss'] != null) Text('Stop Loss: ${a['stop_loss']}'),
            if (a['take_profit'] != null) Text('Take Profit: ${a['take_profit']}'),
            const SizedBox(height: 12),
            const Text('Paper mode only. No real-money order is sent.',
              style: TextStyle(fontWeight: FontWeight.bold)),
          ]))),
      ]),
    );
  }
}
