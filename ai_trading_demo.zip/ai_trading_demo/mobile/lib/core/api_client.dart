import 'dart:convert';
import 'package:http/http.dart' as http;

class ApiClient {
  // Android emulator -> host machine.
  // For a physical phone, replace with your computer's LAN IP.
  static const base = 'http://10.0.2.2:8000';

  Future<Map<String,dynamic>> analyze(String symbol) async {
    final r = await http.post(Uri.parse('$base/api/v1/analyze'),
      headers: {'Content-Type':'application/json'},
      body: jsonEncode({'symbol': symbol, 'interval':'1h'}));
    if (r.statusCode != 200) throw Exception(r.body);
    return jsonDecode(r.body);
  }

  Future<Map<String,dynamic>> account() async {
    final r = await http.get(Uri.parse('$base/api/v1/paper/account'));
    if (r.statusCode != 200) throw Exception(r.body);
    return jsonDecode(r.body);
  }
}
