from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
import httpx
import pandas as pd
import ta
from datetime import date

app = FastAPI(title="AI Trading Assistant Demo", version="0.1.0")

BINANCE = "https://api.binance.com"
START_BALANCE = 10000.0
MAX_RISK = 0.02
DAILY_LOSS_LIMIT = 0.05

paper = {
    "balance": START_BALANCE,
    "starting_day_balance": START_BALANCE,
    "day": str(date.today()),
    "trades": [],
}

class AnalyzeRequest(BaseModel):
    symbol: str = Field(pattern=r"^[A-Z0-9]{5,20}$")
    interval: str = "1h"
    limit: int = Field(default=200, ge=100, le=500)

class PaperOrder(BaseModel):
    symbol: str
    side: str
    entry: float
    stop_loss: float
    take_profit: float
    risk_percent: float = Field(default=0.01, ge=0.001, le=0.02)

async def klines(symbol, interval, limit):
    async with httpx.AsyncClient(timeout=10) as client:
        r = await client.get(f"{BINANCE}/api/v3/klines",
                             params={"symbol": symbol, "interval": interval, "limit": limit})
        r.raise_for_status()
        return r.json()

@app.get("/health")
async def health():
    return {"status": "ok", "mode": "PAPER_TRADING_ONLY"}

@app.get("/api/v1/ticker/{symbol}")
async def ticker(symbol: str):
    symbol = symbol.upper()
    async with httpx.AsyncClient(timeout=10) as client:
        r = await client.get(f"{BINANCE}/api/v3/ticker/price", params={"symbol": symbol})
        if r.status_code != 200:
            raise HTTPException(400, "Invalid symbol")
        return r.json()

@app.post("/api/v1/analyze")
async def analyze(req: AnalyzeRequest):
    data = await klines(req.symbol.upper(), req.interval, req.limit)
    df = pd.DataFrame(data, columns=[
        "time","open","high","low","close","volume","close_time",
        "qav","trades","tbbav","tbqav","ignore"
    ])
    for c in ["open","high","low","close","volume"]:
        df[c] = pd.to_numeric(df[c])

    close = df["close"]
    df["sma20"] = close.rolling(20).mean()
    df["sma50"] = close.rolling(50).mean()
    df["rsi"] = ta.momentum.RSIIndicator(close, window=14).rsi()
    macd = ta.trend.MACD(close)
    df["macd"] = macd.macd()
    df["macd_signal"] = macd.macd_signal()
    x = df.iloc[-1]

    bullish = x.close > x.sma20 > x.sma50 and x.rsi > 50 and x.macd > x.macd_signal
    bearish = x.close < x.sma20 < x.sma50 and x.rsi < 50 and x.macd < x.macd_signal

    if bullish:
        signal = "BUY"
        trend = "BULLISH"
        confidence = 0.70
        sl = float(x.close * 0.98)
        tp = float(x.close * 1.04)
    elif bearish:
        signal = "SELL"
        trend = "BEARISH"
        confidence = 0.70
        sl = float(x.close * 1.02)
        tp = float(x.close * 0.96)
    else:
        signal = "WAIT"
        trend = "NEUTRAL"
        confidence = 0.50
        sl = tp = None

    return {
        "symbol": req.symbol.upper(),
        "price": float(x.close),
        "trend": trend,
        "signal": signal,
        "confidence": confidence,
        "rsi": float(x.rsi),
        "macd": float(x.macd),
        "macd_signal": float(x.macd_signal),
        "sma20": float(x.sma20),
        "sma50": float(x.sma50),
        "stop_loss": sl,
        "take_profit": tp,
        "disclaimer": "Confidence is a model score, not a guaranteed probability of profit."
    }

@app.get("/api/v1/paper/account")
async def paper_account():
    if paper["day"] != str(date.today()):
        paper["day"] = str(date.today())
        paper["starting_day_balance"] = paper["balance"]
    loss = max(0, (paper["starting_day_balance"] - paper["balance"]) /
               paper["starting_day_balance"])
    return {
        "balance": paper["balance"],
        "daily_loss": loss,
        "trading_locked": loss >= DAILY_LOSS_LIMIT,
        "trades": paper["trades"][-50:]
    }

@app.post("/api/v1/paper/order")
async def paper_order(order: PaperOrder):
    if paper["day"] != str(date.today()):
        paper["day"] = str(date.today())
        paper["starting_day_balance"] = paper["balance"]

    daily_loss = max(0, (paper["starting_day_balance"] - paper["balance"]) /
                     paper["starting_day_balance"])
    if daily_loss >= DAILY_LOSS_LIMIT:
        raise HTTPException(403, "Daily 5% loss limit reached")

    risk_amount = paper["balance"] * order.risk_percent
    distance = abs(order.entry - order.stop_loss)
    if distance <= 0:
        raise HTTPException(400, "Invalid stop loss")
    quantity = risk_amount / distance

    trade = {
        "symbol": order.symbol.upper(),
        "side": order.side.upper(),
        "entry": order.entry,
        "stop_loss": order.stop_loss,
        "take_profit": order.take_profit,
        "quantity": quantity,
        "risk_amount": risk_amount,
        "status": "OPEN",
    }
    paper["trades"].append(trade)
    return trade
