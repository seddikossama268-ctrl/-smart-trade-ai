# AI Trading Assistant — Secure Paper Trading Demo

This is a safe, paper-trading-only starter app:
- Flutter mobile UI
- Python FastAPI backend
- Live Binance public market data
- RSI, MACD, SMA20/SMA50 analysis
- BUY/SELL/WAIT signals
- Risk sizing capped at 2%
- Daily loss lock at 5%
- Paper wallet and simulated orders
- No real-money trading and no withdrawal capability

## Backend
cd backend
python -m venv .venv
# Windows: .venv\Scripts\activate
# Linux/macOS: source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000

## Flutter
cd mobile
flutter pub get
flutter run

For Android emulator, the app uses http://10.0.2.2:8000.
For a physical phone, change API base URL in lib/core/api_client.dart to your computer's LAN IP.

This demo deliberately does NOT accept exchange API secrets.
